from flask import Flask
# enabling methods
from flask import request 
# enabling render template
from flask import render_template 
# consuming API
import urllib.request, json
import os
# enabling bootstrap styling
# from flask_bootstrap import Bootstrap
# enabling numpy
import numpy as np
# enabling pickle for model load
import pickle
# enabling HTTP request
import requests
# enabling jsonify
from flask import jsonify
# enabling math to round up
import math
# enabling jwt
import jwt
from flask import session, redirect, url_for, make_response
from datetime import datetime, timedelta

app = Flask(__name__)
# Agar Slashnya bisa auto tambah sendiri
app.url_map.strict_slashes = False
# agar bootstrapnya jalan
# bootstrap = Bootstrap(app)
app.config['SECRET_KEY'] = 'dcaf6fb986654011bd92ec45d768aac1'

@app.route("/")
def hello_world():
    return "<p>Hello Again, World!</p>"

# Testing Passsing Variables
@app.route("/transaction/<int:trx_id>")
def transaction(trx_id):
    return f"<p>Transaction Page {trx_id}</p>"

# Handling Methods
@app.route('/login/', methods=['GET', 'POST'])
def login(name=None):
    if request.method == 'POST':
        # getting input with name = fname in HTML form
       first_name = request.form.get("fname")
       # getting input with name = lname in HTML form 
       last_name = request.form.get("lname") 
       name = first_name + last_name

       # Inserting to SQLITE DB
        # db.execute("INSERT INTO birthdays (name, day, month) VALUES(?, ?, ?)", name, day, month)

       return render_template('login.html', 
            name=name, 
            fname = first_name, 
            lname = last_name
            )
    else:
        return render_template('login.html', name=name)

# Consuming API
@app.route("/movie/")
def get_movies():
    # url = "https://api.themoviedb.org/3/discover/movie?api_key={}".format(os.environ.get("TMDB_API_KEY"))
    API_KEY = "cdef2911baa45c5ee306ed5add700694"
    url = "https://api.themoviedb.org/4/discover/movie?api_key=cdef2911baa45c5ee306ed5add700694"

    response = urllib.request.urlopen(url)
    data = response.read()
    dict = json.loads(data)

    # return dict
    # return list(dict.items())[0]
    return render_template ("movie.html", movies=dict['results'])

# Consuming API + Bootstrap
@app.route("/movie-boot/")
def get_movies_boot():
    # url = "https://api.themoviedb.org/3/discover/movie?api_key={}".format(os.environ.get("TMDB_API_KEY"))
    API_KEY = "cdef2911baa45c5ee306ed5add700694"
    url = "https://api.themoviedb.org/4/discover/movie?api_key=cdef2911baa45c5ee306ed5add700694"

    response = urllib.request.urlopen(url)
    data = response.read()
    dict = json.loads(data)

    # return dict
    # return list(dict.items())[0]
    return render_template ("movie-bootstrap.html", movies=dict['results'])

# Handling Methods in ML Models
@app.route('/predict2/', methods=['GET', 'POST'])
def predict2(output=None):
    if request.method == 'POST':
        # getting input with name = fname in HTML form
        yoe = request.form.get("YearsExperience")
        yoe = int(yoe)
        
        # agar bisa me-load pickle model
        model = pickle.load(open('regression/model.pkl', 'rb'))
        # prediksi angka
        prediction = model.predict([[np.array(yoe)]])
        # ambil array 0
        
        output = math.ceil(prediction[0])
        return render_template('prediction.html', prediction_text='Salary is {}'.format(output))
    else:
        return render_template('prediction.html', prediction_text='Salary Not Inserted')

#-----------------------------------------------------------------------------------------------
# JWT Token - Login System
current_token = ''
@app.route("/secret/", methods=['GET', 'POST'])
def secret():
    if not session.get('logged_in'):
        session_status = 'No Session'
        return render_template('secret.html', session_status_now=session_status)
    else:
        session_status = 'Session Active'
        return render_template('secret.html', session_status_now=session_status)

@app.route('/get-token/', methods=['POST'])
def get_token():
    if request.form['username'] and request.form['password'] == '123456':
        session['logged_in'] = True

        token = jwt.encode({
            'user': request.form['username'],
            # don't foget to wrap it in str function, otherwise it won't work [ i struggled with this one! ]
            'expiration': str(datetime.utcnow() + timedelta(seconds=60))
        },
            app.config['SECRET_KEY'])
        # return jsonify({'token': token})
        return render_template('secret.html', session_status_now='The Token is : {}'.format(token))
    else:
        return redirect('/secret/')

@app.route('/delete-token/', methods=['POST'])
def delete_token():
    session['logged_in'] = False
    # return render_template('secret.html', session_status_now='Sucessfully Logged Out')
    return redirect('/secret/')

# Handling
@app.route("/about/")
def about():
    return "<p>About Page</p>" 


# export FLASK_APP=mantap-2
# export FLASK_ENV=development
# flask run   