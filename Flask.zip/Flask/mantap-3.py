from flask import Flask
# enabling methods
from flask import request 
# enabling render template
from flask import render_template 
# consuming API
import urllib.request, json
import os
# enabling bootstrap styling
# from flask_bootstrap import Bootstrap
# enabling numpy
import numpy as np
# enabling pickle for model load
import pickle
# enabling HTTP request
import requests
# enabling jsonify
from flask import jsonify
# enabling math to round up
import math
# enabling jwt
import jwt
from flask import session, redirect, url_for, make_response, flash
from datetime import datetime, timedelta
import sqlite3 as sql
from flask_session import Session
import pandas as pd
import xlsxwriter
from flask_bcrypt import Bcrypt

app = Flask(__name__)
# Agar Slashnya bisa auto tambah sendiri
app.url_map.strict_slashes = False
# agar bootstrapnya jalan
# bootstrap = Bootstrap(app)
app.config['SECRET_KEY'] = 'dcaf6fb986654011bd92ec45d768aac1'

# create a session object
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Bcrypt
bcrypt = Bcrypt(app)

try:
    # Configure CS50 Library to use SQLite database
    # db = sql("sqlite:///approval.db")
    db = sql.connect('approval.db')
    cur = db.cursor()
    print("Database created and Successfully Connected to SQLite")

    # Drop If Any Table
    cur.execute("DROP TABLE IF EXISTS users")
    cur.execute("DROP TABLE IF EXISTS transactions")

    # Create table USERS
    cur.execute('''CREATE TABLE users
        (user_id INTEGER primary key autoincrement, 
            username text, 
            password text, 
            balance integer,
            accesslevel text)
        ''')

    # Insert a row of data on USERS
    # cur.execute('''INSERT INTO users VALUES (1, 'AAA','123', 100000, 'Admin')''')
    # cur.execute('''INSERT INTO users VALUES (2, 'BBB','123', 100000, 'Admin')''')
    # cur.execute('''INSERT INTO users VALUES (3, 'CCC','123', 100000, 'View')''')

    # Create table TRANSACTION
    cur.execute('''CREATE TABLE transactions
        (transaction_id INTEGER primary key autoincrement, 
            username_from text not null, 
            username_to text not null,
            amount integer not null,
            datetime text not null)
        ''')

    # Insert a row of data on USERS
    # cur.execute('''INSERT INTO transactions VALUES (1, 'AAA', 'BBB', 50000, datetime('now', 'localtime'))''')

    # Display data inserted - USERS
    print("Data Inserted in the table: ")
    data=cur.execute('''SELECT * FROM users ''')
    for row in data:
        print(row)

    # Display data inserted - TRANSACTIONS
    print("Data Inserted in the table: ")
    data=cur.execute('''SELECT * FROM transactions ''')
    for row in data:
        print(row)

    # Save (commit) the changes
    db.commit()

except sql.Error as error:
    print("Error while connecting to sqlite : ", error)


@app.route("/")
def hello_world():
    return redirect(url_for('login'))
    # return redirect('cs50-login.html', name=name, session=session)

# Handling Methods
@app.route('/register/', methods=['GET', 'POST'])
def register(name=None):
    if request.method == 'POST':
        user_name = request.form.get("name")
        print(user_name)

        # Query database for username to validate uniqueness
        rows = cur.execute("SELECT * FROM users WHERE username = ?", (user_name,))
        records = rows.fetchall()
        if len(records) == 0:
            # getting input with name = lname in HTML form 
            user_password = request.form.get("password")
            user_password_hash = bcrypt.generate_password_hash(user_password)
            print(user_password_hash)

            accesslevel = 'Admin'
            
            # Inserting to SQLITE DB
            cur.execute("INSERT INTO users (username, password, balance, accesslevel) VALUES(?, ?, ?, ?)", (user_name, user_password_hash, 100000, accesslevel))
            flash('Successfully Registrated!', 'success')

            # Username as Session
            session['username'] = user_name
            session['access'] = accesslevel

            # Query database for ALL username
            rows = cur.execute("SELECT * FROM users WHERE username = ?", (session['username'],))
            records = rows.fetchall()

            return render_template('cs50-register.html',
                records = records, 
                name=user_name, 
                password = user_password_hash,
                session=session
                )
        else:
            flash("User Already Exist, Please Use Another Username", 'error')
            return render_template('cs50-register.html', name=name, session=session)
        
    else:
        return render_template('cs50-register.html', name=name, session=session)

# Handling Methods
@app.route('/login/', methods=['GET', 'POST'])
def login(name=None):
    if request.method == 'POST':
        # getting input with name = fname in HTML form
        username = request.form.get("name")
        print("username inserted : " + username)
        # getting input with name = lname in HTML form 
        password = request.form.get("password")

        # Query database for ALL username
        rows = cur.execute("SELECT * FROM users")
        records = rows.fetchall()
        print("Total ALL Rows are : ", len(records))
        print("Printing each row")
        for row in records:
            print("Username: ", row[0])
            print("Password: ", row[1])
            


        # Query database for username
        rows = cur.execute("SELECT * FROM users WHERE username = ?", (username,))
        records = rows.fetchall()
        # records = rows.fetchone()
        print("Total Found Rows are : ", len(records))
        if len(records) > 0:
            for row in records:
                print("Username: ", row[1])
                session['username'] = row[1]
                session['access']=row[4]
                print("Password: ", row[2])
                # flash("Decrypting Password...", 'success')
                if not bcrypt.check_password_hash(row[2], password):
                    session.pop('username', None)
                    print("Wrong Credentials : Password Incorrect")
                    flash("Wrong Credentials : Password Incorrect", 'error')
                    return render_template('cs50-login.html', name=name, records=records, session=session)
                else:
                    print("Successfullly Logged In : " + str(row[1]))
                    flash("Successfullly Logged In : " + str(row[1]), 'success')
                    return render_template('cs50-login.html', name=name, records=records, session=session)
        else:
            session.pop('username', None)
            print("Wrong Credentials!")
            flash("Wrong Credentials!", 'error')
            return render_template('cs50-login.html', name=name, records=records, session=session)

    else:
        # flash('Not Logged In!')
        return render_template('cs50-login.html', name=name, session=session)

# Handling Methods
@app.route('/logout/', methods=['GET', 'POST'])
def logout():
    name = None
    session.pop('username', None)
    session.pop('access', None)
    flash('Successful Log Out!', 'success')
    return render_template('cs50-login.html', name=name, session=session)

# Handling
@app.route("/user_management/", methods=['GET', 'POST'])
def userlist():
    name = session['username']
    access = session['access']
    if access == 'Admin':
        # Query database for ALL username
        rows = cur.execute("SELECT * FROM users")
        records = rows.fetchall()
        print("Total ALL Rows are : ", len(records))
        print("Printing each row")
        for row in records:
            print("Username: ", row[0])
            print("Password: ", row[1])
            print("Balance: ", row[2])
        if request.method == 'POST':
            # getting input from Amount 
            user_row_number = request.form.get("rownumber")
            print("Clicked User Row : " + user_row_number)
            rows = cur.execute("DELETE FROM users WHERE user_id = ?", (user_row_number))
            rows = cur.execute("SELECT * FROM users")
            records = rows.fetchall()
            # records = rows.fetchall()
            # return redirect(url_for('userlist'), code =302)
            # return redirect('cs50-userlist.html', name=name, records=records, session=session)
            return render_template('cs50-userlist.html', name=name, records=records, session=session)
        else:
            return render_template('cs50-userlist.html', name=name, records=records, session=session)
    else:
        flash('Access Level is not Authorized to access this page', 'error')
        return render_template('cs50-login.html', name=name, session=session)

# UPDATE USER NIH WOOOYYY!
@app.route("/user_management_edit/<int:rownumber>", methods=['GET', 'POST'])
def userlistedit(rownumber):
    name = session['username']

    user_row_number = rownumber
    print("Clicked User Row to EDIT : " + str(user_row_number))
    rows = cur.execute("SELECT * FROM users WHERE user_id = ?", (user_row_number,))

    records = rows.fetchall()
    print("SELECTED USER ID : ", len(records))
    print("Printing each row")
    for row in records:
        print("Username: ", row[1])
        print("Password: ", row[2])
        print("Balance: ", row[3])
        print("Access Level: ", row[4])
    if request.method == 'POST':
        # ISI NIH KALO NGEUPDATE GMNA
        #
        rows = cur.execute('''
            UPDATE users 
            SET
                username = ?,
                balance = ?,
                accesslevel = ?    
            WHERE 
                user_id = ?''', (request.form.get("nameTaken"),
                    request.form.get("balanceTaken"),
                    request.form.get("accessLevel"),
                    user_row_number,))
        records = rows.fetchall()
        print("Successfully Updated")
        #
        # Re-Querying
        rows = cur.execute("SELECT * FROM users")
        records = rows.fetchall()
        flash('Successfully Updated!', 'success')

        return render_template('cs50-userlist.html', name=name, records=records, session=session)
    else:
        return render_template('cs50-userlist-edit.html', data_takens=records, session=session)

# Handling
@app.route("/transaction/", methods=['GET', 'POST'])
def transaction():
    if request.method == 'POST':
        rows = cur.execute("SELECT * FROM users")
        records = rows.fetchall()
        print("=============== [Transaction] : Start Route ===============")
        transaction_user_from = session['username']
        print("USER_FROM : " + transaction_user_from)
        # getting input from NameTo
        transaction_user_destination = request.form.get("nameTo")
        print("USER_DEST : " + transaction_user_destination)
        # getting input from Amount 
        transaction_amount = request.form.get("amount")
        print("AMT : " + transaction_amount)
        transaction_datetime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # Validating Amount USER FROM
        # Query database for username
        print("=============== [Transaction] : Validating Amount USER FROM ===============")
        rows = cur.execute("SELECT * FROM users WHERE username = ?", (session['username'],))
        records = rows.fetchall()
        # Assigning Beginning Value
        if len(records) > 0:
            for row in records:
                print("ORI_Username: ", row[1])
                print("ORI_Balance: ", row[2])
                transaction_user_from_id = row[0]
                transaction_user_from_amount = row[3] 
            flash("Obtaining Data from User : " + str(transaction_user_from), 'success')
        else:
            flash("UserFrom Balance Corrupted", 'error')

        # Validating Amount USER DEST
        # Query database for username
        print("=============== [Transaction] : Validating Amount USER DEST ===============")
        rows = cur.execute("SELECT * FROM users WHERE username = ?", (request.form.get("nameTo"),))
        records = rows.fetchall()
        # records = rows.fetchone()
        print("Total Found Rows are : ", len(records))
        if len(records) > 0:
            for row in records:
                print("DEST_Username: ", row[1])
                print("DEST_Balance: ", row[2])
                transaction_user_destination_id = row[0]
                transaction_user_destination_amount = row[3]
        else:
            flash("Destination not Available!", 'error')
        
        # Make Sure Balance is Sufficient
        # transaction_user_from_amount = 0
        transaction_user_from_amount = int(transaction_user_from_amount) - int(transaction_amount)
        if transaction_user_from_amount <= 0:
            print("Balance is NOT SUFFICIENT")
            flash("Balance is NOT SUFFICIENT", 'error')

            # Refreshing Template
            rows = cur.execute("SELECT * FROM users WHERE username NOT IN (?)", (session['username'],))
            records = rows.fetchall()
            return render_template('cs50-transaction.html', records = records, name=session['username'], session=session)
        else:
            print("Balance is Sufficient")
        
            # Reducing Balance from USER FROM
            print("=============== [Transaction] : Reducing Balance from USER FROM  ===============")
            # Query
            rows = cur.execute('''
                UPDATE users 
                SET
                    username = ?,
                    balance = ?    
                WHERE 
                    user_id = ?''', (transaction_user_from,
                        transaction_user_from_amount,
                        transaction_user_from_id,))
            records = rows.fetchall()
            print("Successfully Reducing Balance")

            # Increasing Balance to USER DEST
            print("=============== [Transaction] : Transfer Balance to USER DEST  ===============")
            transaction_user_destination_amount = int(transaction_user_destination_amount) + int(transaction_amount)
            # Query
            rows = cur.execute('''
                UPDATE users 
                SET
                    username = ?,
                    balance = ?    
                WHERE 
                    user_id = ?''', (transaction_user_destination,
                        transaction_user_destination_amount,
                        transaction_user_destination_id,))
            records = rows.fetchall()

            # Inserting to SQLITE DB
            cur.execute('''INSERT INTO transactions (username_from, username_to, amount, datetime) VALUES(?,?,?,?)''', (transaction_user_from, transaction_user_destination, transaction_amount, transaction_datetime))
            flash('Transaction Successful!', 'success')

            return render_template('cs50-transaction.html', records = records, name=session['username'], session=session)
    else:
        rows = cur.execute("SELECT * FROM users WHERE username NOT IN (?)", (session['username'],))
        records = rows.fetchall()
        return render_template('cs50-transaction.html', records = records, name=session['username'], session=session)

# Handling
@app.route("/transaction_history/", methods=['GET'])
def transactionhistory():
    name = session['username']
    # Query database for ALL username
    rows = cur.execute("SELECT * FROM transactions WHERE username_from = ? OR username_to = ?", (session['username'], session['username'],))
    records = rows.fetchall()
    print("Total ALL Rows are : ", len(records))
    print("Printing each row")
    for row in records:
        print("Username: ", row[0])
        print("Password: ", row[1])
        print("Balance: ", row[2])
    
    return render_template('cs50-transactionhistory.html', name=name, records=records, session=session)

# Upload
@app.route("/upload", methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        print(request.files['file'])
        f = request.files['file']
        file_extension = f.filename.split('.')[1]
        if file_extension == 'xlsx':
            df = pd.read_excel(f.read(), engine='openpyxl')
        elif file_extension == 'xls':
            df = pd.read_excel(f.read())
        elif file_extension == 'csv':
            df = pd.read_csv(f.read())
        # data_xls = pd.read_excel(f, index_col=0)
        print(df.head)
        # crossroute variable assignment
        df = pd.DataFrame(df)
        session['registerData'] = df.to_json()
        print(session['registerData'])
        print("=============== [Upload] : Register Data Assigned ===============")
        flash('Successfully Uploaded!', 'success')
        return render_template('cs50-upload-result.html',  tables=[df.to_html(classes='data')], titles=df.columns.values, name=session['username'], session=session)
    return render_template('cs50-upload.html', name=session['username'], session=session)

# Export
@app.route("/export", methods=['GET'])
def export_records():
    try:
        # Create a workbook and add a worksheet.
        print("=============== [Export] : Creating Excel File ===============")
        workbook = xlsxwriter.Workbook('Output.xlsx')
        worksheet = workbook.add_worksheet()

        print("=============== [Export] : Obtaining Database ===============")
        # Some data we want to write to the worksheet.
        rows = cur.execute("SELECT * FROM users")
        datas = rows.fetchall()
        print(datas)

        # Start from the first cell. Rows and columns are zero indexed.
        row = 1
        col = 0

        # Creating Columns
        bold = workbook.add_format({'bold': True})
        worksheet.write('A1', "userid", bold)
        worksheet.write('B1', "username", bold)
        worksheet.write('C1', "password", bold)
        worksheet.write('D1', "balance", bold)
        worksheet.write('E1', "accesslevel", bold)

        print("=============== [Export] : Iterating Data ===============")
        # Iterate over the data and write it out row by row.
        for userid, username, password, balance, accesslevel in (datas):
            worksheet.write(row, col,     userid)
            worksheet.write(row, col + 1, username)
            worksheet.write(row, col + 2, str(password))
            worksheet.write(row, col + 3, balance)
            worksheet.write(row, col + 4, accesslevel)
            row += 1    

        print("=============== [Export] : Closing Connection ===============")
        workbook.close()
        print("File saved successfully!")
        flash("File saved successfully!", 'success')
    except:
        print("Error to Export Excel")
        flash("Error to Export Excel", 'error')
    return render_template('cs50-userlist.html', name=session['username'], records=datas, session=session)


# Register Bulk
@app.route('/register-bulk/', methods=['GET', 'POST'])
def register_bulk():
    print("=============== [Register Bulk] - Process ===============")
    df = session['registerData']
    df = pd.read_json(df)
    # Filtering Username and Password Only
    df = pd.DataFrame(df, columns=['Username', 'Password', 'Balance','AccessLevel'])
    print(df)

    # Iterating Password Hash
    # for row in data:
    #     print(row)
    # df['PasswordHash'] = ['']


    print("=============== [Register Bulk] - Validate Username Entries Iteration ===============")
    i = 0
    username_found_counter = 0
    for x, y in df['Username'].items():
        print('y = ' + str(i) + " --- " + str(y))
        rows = cur.execute("SELECT * FROM users WHERE username = ?", (y,))
        records = rows.fetchall()
        if len(records) == 0:
            print(y + " --- Username Available to Use")
            # flash("Username Available : " + str(y), 'success')
        else:
            username_found_counter += 1
            print(y + " --- Username has Taken")
            flash("Username Has Already Taken : " + str(y) + " --- Please Revise.", 'error')
        i += 1
        username_found_counter = max(0,username_found_counter)
        print("username found counter : " + str(username_found_counter))


    print("=============== [Register Bulk] - Hashing Iteration ===============")
    i = 0
    for x, y in df['Password'].items():
        print('y = ' + str(y))
        df.loc[df.index[i], 'PasswordHash'] = bcrypt.generate_password_hash(str(y))
        i += 1
    
    print(df)

    # Replacing df['Password'] with the newly hashed
    print("=============== [Register Bulk] - Dropping Hash Column ===============")
    df['Password'] = df['PasswordHash']
    df = df.drop(columns =['PasswordHash'])
    print(df)

    # Converting Dataframe to List (cuz SQLITE 3 only accept list to insert)
    df = df.values.tolist()

    if username_found_counter == 0:
        if request.method == 'POST':
            
            # Inserting to SQLITE DB
            cur.executemany("INSERT INTO users (username, password, balance, accesslevel) VALUES(?, ?, ?, ?)", df)
            flash('ALL Entries in Excel are Successfully Executed!', 'success')

            return render_template('cs50-register-bulk.html', 
                name = session['username'],
                data=data,
                session=session
                )
        else:
            return render_template('cs50-register-bulk.html',
                name = session['username'],
                data=data,
                session=session)
    else:
        return render_template('cs50-register-bulk.html',
                name = session['username'],
                data=data,
                session=session)

if __name__ == "__main__":
    app.run()



# Handling
@app.route("/about/")
def about():
    return "<p>About Page</p>" 


# export FLASK_APP=mantap-3
# export FLASK_ENV=development
# flask run --host=0.0.0.0