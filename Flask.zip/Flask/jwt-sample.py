import jwt
# from jwt import PyJWT

SECRET_CODE = 'buatcobacobasaja'
jwt_payload = {
    "platform_name" : "platform_A",
    "level": "manager"
}

get_code = jwt.encode(jwt_payload, SECRET_CODE, algorithm='HS256')
print("CODE : " + get_code)

print("..........................................")

get_decode = jwt.decode(get_code, SECRET_CODE, algorithms="HS256")
print("DECODED : ", get_decode)